import { useState, useEffect, useRef } from 'react'
import { supabase } from '../utils/supabase/client'

type ExpenseStatus = '미신청' | '진행중' | '신청완료' | '팀장 처리중' | '팀원 처리중'

interface Trip {
  id: number
  destination: string
  purpose: string
  companion?: string
  startDate: string
  endDate: string
  expenseStatus: ExpenseStatus
  amount?: number
  note?: string
  googleEventId?: string
}

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined

const STATUS_DOT_COLOR: Record<ExpenseStatus, string> = {
  미신청: '#9ca3af',
  진행중: '#F5C518',
  신청완료: '#22c55e',
  '팀장 처리중': '#f97316',
  '팀원 처리중': '#a855f7',
}

const STATUS_CONFIG: Record<ExpenseStatus, { label: string; bg: string; text: string; border: string; dot: string; emoji: string }> = {
  미신청: { label: '미신청', bg: 'bg-gray-100', text: 'text-gray-500', border: 'border-gray-200', dot: 'bg-gray-400', emoji: '📋' },
  진행중: { label: '진행중', bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-200', dot: 'bg-yellow-400', emoji: '⏳' },
  신청완료: { label: '신청완료', bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200', dot: 'bg-green-500', emoji: '✅' },
  '팀장 처리중': { label: '팀장 처리중', bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200', dot: 'bg-orange-400', emoji: '👔' },
  '팀원 처리중': { label: '팀원 처리중', bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-purple-200', dot: 'bg-purple-400', emoji: '🙋' },
}

function formatDate(d: string) {
  const [y, m, day] = d.split('-')
  return `${y}.${m}.${day}`
}

function formatAmount(n: number) {
  return n.toLocaleString('ko-KR') + '원'
}

function diffDays(start: string, end: string) {
  const s = new Date(start)
  const e = new Date(end)
  return Math.round((e.getTime() - s.getTime()) / 86400000) + 1
}

const EMPTY_FORM = {
  destination: '',
  purpose: '',
  companion: '',
  startDate: '',
  endDate: '',
  expenseStatus: '미신청' as ExpenseStatus,
  amount: '',
  note: '',
}

function DoraBase({ size, children }: { size: number; children: React.ReactNode }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="44" r="38" fill="#00A0E9" />
      <ellipse cx="50" cy="52" rx="28" ry="24" fill="white" />
      {children}
      <rect x="12" y="80" width="76" height="8" rx="4" fill="#E60012" />
      <circle cx="50" cy="90" r="7" fill="#F5C518" stroke="#E6A800" strokeWidth="1" />
      <line x1="50" y1="86" x2="50" y2="88" stroke="#1a1a1a" strokeWidth="1" />
      <circle cx="50" cy="91" r="1.5" fill="#1a1a1a" />
    </svg>
  )
}

function Whiskers() {
  return <>
    <line x1="14" y1="52" x2="36" y2="54" stroke="#1a1a1a" strokeWidth="1.2" strokeLinecap="round" />
    <line x1="14" y1="57" x2="36" y2="57" stroke="#1a1a1a" strokeWidth="1.2" strokeLinecap="round" />
    <line x1="14" y1="62" x2="36" y2="60" stroke="#1a1a1a" strokeWidth="1.2" strokeLinecap="round" />
    <line x1="64" y1="54" x2="86" y2="52" stroke="#1a1a1a" strokeWidth="1.2" strokeLinecap="round" />
    <line x1="64" y1="57" x2="86" y2="57" stroke="#1a1a1a" strokeWidth="1.2" strokeLinecap="round" />
    <line x1="64" y1="60" x2="86" y2="62" stroke="#1a1a1a" strokeWidth="1.2" strokeLinecap="round" />
  </>
}

function DoraemonFace({ size = 80 }: { size?: number }) {
  return (
    <DoraBase size={size}>
      <circle cx="38" cy="38" r="10" fill="white" />
      <circle cx="62" cy="38" r="10" fill="white" />
      <circle cx="40" cy="40" r="5" fill="#1a1a1a" />
      <circle cx="64" cy="40" r="5" fill="#1a1a1a" />
      <circle cx="42" cy="38" r="1.5" fill="white" />
      <circle cx="66" cy="38" r="1.5" fill="white" />
      <circle cx="50" cy="50" r="4" fill="#E60012" />
      <Whiskers />
      <path d="M38 62 Q50 72 62 62" stroke="#1a1a1a" strokeWidth="1.5" strokeLinecap="round" fill="none" />
    </DoraBase>
  )
}

function DoraemonWorried({ size = 80 }: { size?: number }) {
  return (
    <DoraBase size={size}>
      <circle cx="38" cy="38" r="10" fill="white" />
      <circle cx="62" cy="38" r="10" fill="white" />
      <circle cx="40" cy="36" r="5" fill="#1a1a1a" />
      <circle cx="64" cy="36" r="5" fill="#1a1a1a" />
      <circle cx="41.5" cy="35" r="1.5" fill="white" />
      <circle cx="65.5" cy="35" r="1.5" fill="white" />
      <path d="M30 26 Q38 22 44 27" stroke="#1a1a1a" strokeWidth="2" strokeLinecap="round" fill="none" />
      <path d="M56 27 Q62 22 70 26" stroke="#1a1a1a" strokeWidth="2" strokeLinecap="round" fill="none" />
      <circle cx="50" cy="50" r="4" fill="#E60012" />
      <Whiskers />
      <path d="M40 64 Q50 60 60 64" stroke="#1a1a1a" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      <ellipse cx="72" cy="32" rx="3" ry="4.5" fill="#60c3f5" opacity="0.8" />
      <ellipse cx="72" cy="32" rx="1.5" ry="1" fill="white" opacity="0.5" />
    </DoraBase>
  )
}

function DoraemonThinking({ size = 80 }: { size?: number }) {
  return (
    <DoraBase size={size}>
      <circle cx="38" cy="38" r="10" fill="white" />
      <circle cx="62" cy="38" r="10" fill="white" />
      <circle cx="42" cy="36" r="5" fill="#1a1a1a" />
      <circle cx="66" cy="36" r="5" fill="#1a1a1a" />
      <circle cx="43.5" cy="35" r="1.5" fill="white" />
      <circle cx="67.5" cy="35" r="1.5" fill="white" />
      <path d="M30 28 Q38 25 44 29" stroke="#1a1a1a" strokeWidth="2" strokeLinecap="round" fill="none" />
      <path d="M56 29 Q62 25 70 28" stroke="#1a1a1a" strokeWidth="2" strokeLinecap="round" fill="none" />
      <circle cx="50" cy="50" r="4" fill="#E60012" />
      <Whiskers />
      <path d="M40 63 Q48 65 58 62" stroke="#1a1a1a" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      <circle cx="76" cy="22" r="2" fill="#00A0E9" opacity="0.5" />
      <circle cx="82" cy="15" r="3" fill="#00A0E9" opacity="0.5" />
      <circle cx="90" cy="8" r="4" fill="#00A0E9" opacity="0.5" />
    </DoraBase>
  )
}

function DoraemonHappy({ size = 80 }: { size?: number }) {
  return (
    <DoraBase size={size}>
      <circle cx="38" cy="38" r="10" fill="white" />
      <circle cx="62" cy="38" r="10" fill="white" />
      <path d="M30 40 Q38 30 46 40" stroke="#1a1a1a" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      <path d="M54 40 Q62 30 70 40" stroke="#1a1a1a" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      <circle cx="28" cy="52" r="7" fill="#FF6B6B" opacity="0.35" />
      <circle cx="72" cy="52" r="7" fill="#FF6B6B" opacity="0.35" />
      <circle cx="50" cy="50" r="4" fill="#E60012" />
      <Whiskers />
      <path d="M34 60 Q50 76 66 60" stroke="#1a1a1a" strokeWidth="1.8" strokeLinecap="round" fill="none" />
      <text x="76" y="24" fontSize="10" fill="#F5C518">★</text>
      <text x="10" y="24" fontSize="7" fill="#F5C518">★</text>
    </DoraBase>
  )
}

const STORAGE_KEY = 'trippocket_trips'

function loadTrips(): Trip[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

function persistTrips(trips: Trip[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(trips))
}


function encodeTripsToUrl(trips: Trip[]): string {
  const b64 = btoa(encodeURIComponent(JSON.stringify(trips)))
  return `${window.location.origin}${window.location.pathname}#share=${b64}`
}

async function shortenUrl(longUrl: string): Promise<string> {
  const res = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(longUrl)}`)
  if (!res.ok) throw new Error('shorten failed')
  return res.text()
}

function decodeShareParam(): Trip[] | null {
  const match = window.location.hash.match(/^#share=(.+)$/)
  if (!match) return null
  try { return JSON.parse(decodeURIComponent(atob(match[1]))) } catch { return null }
}

// 컴포넌트 외부에서 한 번만 계산
const _sharedTrips = decodeShareParam()
const _isSharedView = _sharedTrips !== null

export default function App() {
  const isSharedView = _isSharedView

  const [trips, setTrips] = useState<Trip[]>(() => isSharedView ? (_sharedTrips ?? []) : loadTrips())
  const [filter, setFilter] = useState<ExpenseStatus | '전체'>('전체')
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(EMPTY_FORM)
  const [editId, setEditId] = useState<number | null>(null)
  const [detailId, setDetailId] = useState<number | null>(null)
  const [checked, setChecked] = useState<Set<number>>(new Set())
  const [shareCopied, setShareCopied] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [shareUrl, setShareUrl] = useState('')
  const [toast, setToast] = useState('')
  const [showSplash, setShowSplash] = useState(!isSharedView)
  const currentMonth = new Date().toISOString().slice(0, 7)
  const [monthFilter, setMonthFilter] = useState<string | null>(null)
  const [selectedStatMonth, setSelectedStatMonth] = useState<string>(currentMonth)
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(5)
  const [showMoreMenu, setShowMoreMenu] = useState(false)
  const [dbReady, setDbReady] = useState(false)
  const [dbLoading, setDbLoading] = useState(!isSharedView)
  const [googleToken, setGoogleToken] = useState<string | null>(null)
  const [gcalConnected, setGcalConnected] = useState(false)
  const googleTokenRef = useRef<string | null>(null)  // stale closure 방지
  const gcalConnectedRef = useRef(false)
  const userIdRef = useRef<string | null>(null)
  const rowIdRef = useRef<string | null>(null)
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const tokenClientRef = useRef<any>(null)

  // Google Identity Services 로드
  useEffect(() => {
    if (!GOOGLE_CLIENT_ID || isSharedView) return
    const script = document.createElement('script')
    script.src = 'https://accounts.google.com/gsi/client'
    script.async = true
    script.onload = () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const w = window as any
      if (!w.google) return
      tokenClientRef.current = w.google.accounts.oauth2.initTokenClient({
        client_id: GOOGLE_CLIENT_ID,
        scope: 'https://www.googleapis.com/auth/calendar.events',
        callback: (resp: { access_token?: string; error?: string }) => {
          if (resp.access_token) {
            googleTokenRef.current = resp.access_token
            gcalConnectedRef.current = true
            setGoogleToken(resp.access_token)
            setGcalConnected(true)
            showToast('📅 Google Calendar 연동 완료!')
          }
        },
      })
    }
    document.head.appendChild(script)
    return () => { if (document.head.contains(script)) document.head.removeChild(script) }
  }, [])

  function handleConnectGCal() {
    if (!GOOGLE_CLIENT_ID) { showToast('⚠️ Google Client ID가 설정되지 않았습니다'); return }
    // 최초 연동은 consent, 이미 연동된 상태에서 재클릭하면 silent refresh
    const prompt = gcalConnectedRef.current ? '' : 'consent'
    tokenClientRef.current?.requestAccessToken({ prompt })
  }

  // API 호출 전 유효한 토큰 확인 후 반환 (만료 시 silent refresh)
  function getToken(): Promise<string | null> {
    const token = googleTokenRef.current
    if (!gcalConnectedRef.current || !tokenClientRef.current) return Promise.resolve(null)
    if (token) return Promise.resolve(token)
    // 토큰 없으면 silent refresh 시도
    return new Promise((resolve) => {
      const orig = tokenClientRef.current.callback
      tokenClientRef.current.callback = (resp: { access_token?: string }) => {
        tokenClientRef.current.callback = orig
        if (resp.access_token) {
          googleTokenRef.current = resp.access_token
          setGoogleToken(resp.access_token)
          resolve(resp.access_token)
        } else {
          resolve(null)
        }
      }
      tokenClientRef.current.requestAccessToken({ prompt: '' })
    })
  }

  function buildGCalBody(trip: Trip) {
    const description = [
      trip.purpose,
      trip.companion ? `동행인: ${trip.companion}` : '',
      trip.note ? `메모: ${trip.note}` : '',
    ].filter(Boolean).join('\n')
    const endDate = new Date(trip.endDate)
    endDate.setDate(endDate.getDate() + 1)
    return {
      summary: `[출장] ${trip.destination}`,
      location: trip.destination,
      description,
      start: { date: trip.startDate },
      end: { date: endDate.toISOString().slice(0, 10) },
    }
  }

  async function createGCalEvent(trip: Trip, token: string): Promise<string | null> {
    try {
      const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(buildGCalBody(trip)),
      })
      if (!res.ok) throw new Error('api error')
      const data = await res.json()
      return data.id as string
    } catch {
      return null
    }
  }

  async function updateGCalEvent(eventId: string, trip: Trip, token: string): Promise<boolean> {
    try {
      const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(buildGCalBody(trip)),
      })
      return res.ok
    } catch {
      return false
    }
  }

  async function deleteGCalEvent(eventId: string, token: string): Promise<boolean> {
    try {
      const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
      })
      return res.ok || res.status === 410 // 410 = already deleted
    } catch {
      return false
    }
  }

  // Supabase 초기 세션 확인
  useEffect(() => {
    if (isSharedView) return
    async function init() {
      try {
        const { data: sessionData } = await supabase.auth.getSession()
        const uid = sessionData?.session?.user?.id
        if (uid) {
          userIdRef.current = uid
          const { data: row } = await supabase.from('trips').select('id, data').eq('user_id', uid).maybeSingle()
          if (row) {
            rowIdRef.current = row.id
            if (Array.isArray(row.data) && row.data.length > 0) {
              const loaded = row.data as Trip[]
              setTrips(loaded)
              persistTrips(loaded)
            }
          }
          setDbReady(true)
        } else {
          const { data: anonData, error } = await supabase.auth.signInAnonymously()
          if (error) throw error
          const newUid = anonData?.user?.id
          if (newUid) userIdRef.current = newUid
          setDbReady(true)
        }
      } catch {
        setDbReady(false)
      } finally {
        setDbLoading(false)
      }
    }
    init()
  }, [])

  // trips 변경 시 Supabase에 저장 (디바운스 500ms)
  useEffect(() => {
    if (isSharedView) {
      return
    }
    persistTrips(trips) // 항상 로컬 캐시 업데이트
    if (!dbReady || !userIdRef.current) return
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current)
    saveTimerRef.current = setTimeout(async () => {
      const uid = userIdRef.current
      if (!uid) return
      if (rowIdRef.current) {
        await supabase.from('trips').update({ data: trips, updated_at: new Date().toISOString() }).eq('id', rowIdRef.current)
      } else {
        const { data: newRow } = await supabase.from('trips').insert({ user_id: uid, data: trips }).select('id').single()
        if (newRow) rowIdRef.current = newRow.id
      }
    }, 500)
  }, [trips, dbReady])

  useEffect(() => { setPage(1) }, [filter, monthFilter, sortOrder, pageSize])


  function handleShare() {
    setShowShareModal(true)
  }

  async function handleNativeShare() {
    setShowShareModal(false)
    showToast('🔗 링크 생성 중...')
    try {
      const long = encodeTripsToUrl(trips)
      const url = await shortenUrl(long)
      if (navigator.share) {
        navigator.share({ title: '출장포켓 TripPocket', text: '내 출장 목록을 확인해보세요!', url }).catch(() => {})
      } else {
        copyToClipboard(url)
        showToast('🔗 링크가 복사되었습니다!')
      }
    } catch {
      showToast('❌ 링크 생성에 실패했습니다')
    }
  }

  function exportCSV() {
    const header = ['출장지', '목적', '동행인', '출발일', '복귀일', '처리여부', '금액(원)', '메모']
    const rows = trips.map((t) => [
      t.destination,
      t.purpose,
      t.companion ?? '',
      t.startDate,
      t.endDate,
      t.expenseStatus,
      t.amount ?? '',
      t.note ?? '',
    ])
    const csv = [header, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `출장포켓_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    showToast('📊 CSV 파일이 저장되었습니다')
  }

  function exportPDF() {
    const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    const total = trips.reduce((s, t) => s + (t.amount ?? 0), 0)
    const today = new Date().toLocaleDateString('ko-KR')
    const rows = trips.map((t) => [
      esc(t.destination),
      esc(t.purpose),
      esc(t.companion ?? '-'),
      t.startDate,
      t.endDate,
      esc(t.expenseStatus),
      t.amount ? t.amount.toLocaleString('ko-KR') + '원' : '-',
      esc(t.note ?? '-'),
    ]).map(([dest, purp, comp, start, end, status, amt, note]) => `<tr><td>${dest}</td><td>${purp}</td><td>${comp}</td><td>${start}</td><td>${end}</td><td>${status}</td><td style="text-align:right">${amt}</td><td>${note}</td></tr>`).join('')

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700&display=swap');
        * { font-family: 'Noto Sans KR', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
        body { padding: 24px; color: #1e3a5f; }
        h1 { font-size: 22px; color: #00A0E9; margin-bottom: 4px; }
        .meta { font-size: 11px; color: #888; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th { background: #00A0E9; color: white; padding: 8px 6px; text-align: left; }
        td { padding: 7px 6px; border-bottom: 1px solid #e0f0fa; }
        tr:nth-child(even) td { background: #f0f9ff; }
        .total { text-align: right; margin-top: 12px; font-size: 13px; font-weight: 700; color: #1e3a5f; }
        @media print { body { padding: 12px; } }
      </style></head><body>
      <h1>출장포켓 TripPocket</h1>
      <p class="meta">출력일: ${today} &nbsp;|&nbsp; 총 ${trips.length}건</p>
      <table>
        <thead><tr><th>출장지</th><th>목적</th><th>동행인</th><th>출발일</th><th>복귀일</th><th>처리여부</th><th>금액</th><th>메모</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <p class="total">총 지출금액: ${total.toLocaleString('ko-KR')}원</p>
      <script>window.onload = () => { window.print(); }<\/script>
    </body></html>`

    const w = window.open('', '_blank')
    if (!w) { showToast('팝업을 허용해주세요'); return }
    w.document.write(html)
    w.document.close()
    showToast('📄 인쇄 창이 열렸습니다 (PDF로 저장 가능)')
  }

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  function copyToClipboard(text: string) {
    const doCopy = () => {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none'
      document.body.appendChild(ta)
      ta.focus()
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
    }
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(doCopy)
    } else {
      doCopy()
    }
  }

  async function handleCopyLink() {
    setShowShareModal(false)
    showToast('🔗 링크 생성 중...')
    try {
      const long = encodeTripsToUrl(trips)
      const url = await shortenUrl(long)
      copyToClipboard(url)
      setShareCopied(true)
      showToast('🔗 링크가 복사되었습니다!')
      setTimeout(() => setShareCopied(false), 2500)
    } catch {
      showToast('❌ 링크 생성에 실패했습니다')
    }
  }

  // 월별 집계 (YYYY-MM 기준, 최신순)
  const monthlyStats = (() => {
    const map: Record<string, { count: number; total: number }> = {}
    trips.forEach((t) => {
      const key = t.startDate.slice(0, 7)
      if (!map[key]) map[key] = { count: 0, total: 0 }
      map[key].count++
      map[key].total += t.amount ?? 0
    })
    return Object.entries(map).sort((a, b) => b[0].localeCompare(a[0]))
  })()

  const baseTrips = monthFilter ? trips.filter((t) => t.startDate.slice(0, 7) === monthFilter) : trips

  const unpaidTotal = baseTrips.filter((t) => t.expenseStatus === '미신청').reduce((s, t) => s + (t.amount ?? 0), 0)

  const isInProgress = (t: Trip) => t.expenseStatus === '진행중' || t.expenseStatus === '팀장 처리중' || t.expenseStatus === '팀원 처리중'

  const counts = {
    전체: baseTrips.length,
    미신청: baseTrips.filter((t) => t.expenseStatus === '미신청').length,
    진행중: baseTrips.filter(isInProgress).length,
    신청완료: baseTrips.filter((t) => t.expenseStatus === '신청완료').length,
    '팀장 처리중': baseTrips.filter((t) => t.expenseStatus === '팀장 처리중').length,
    '팀원 처리중': baseTrips.filter((t) => t.expenseStatus === '팀원 처리중').length,
  }

  const filtered = (filter === '전체' ? baseTrips : filter === '진행중' ? baseTrips.filter(isInProgress) : baseTrips.filter((t) => t.expenseStatus === filter))
    .slice()
    .sort((a, b) => sortOrder === 'desc'
      ? b.startDate.localeCompare(a.startDate)
      : a.startDate.localeCompare(b.startDate)
    )

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pagedTrips = filtered.slice((page - 1) * pageSize, page * pageSize)

  function openAdd() {
    setEditId(null)
    setForm(EMPTY_FORM)
    setShowForm(true)
  }

  function openEdit(trip: Trip) {
    setEditId(trip.id)
    setForm({
      destination: trip.destination,
      purpose: trip.purpose,
      companion: trip.companion ?? '',
      startDate: trip.startDate,
      endDate: trip.endDate,
      expenseStatus: trip.expenseStatus,
      amount: trip.amount?.toString() ?? '',
      note: trip.note ?? '',
    })
    setShowForm(true)
    setDetailId(null)
  }

  async function saveForm() {
    if (!form.destination || !form.startDate || !form.endDate) return
    setShowForm(false)

    if (editId !== null) {
      const original = trips.find((t) => t.id === editId)
      const updated: Trip = {
        ...(original ?? {} as Trip),
        ...form,
        id: editId,
        companion: form.companion || undefined,
        amount: form.amount ? Number(form.amount) : undefined,
      }
      setTrips((prev) => prev.map((t) => t.id === editId ? updated : t))

      // Google Calendar 일정 수정: event_id 있는 경우만
      if (gcalConnectedRef.current && original?.googleEventId) {
        const token = await getToken()
        if (token) {
          const ok = await updateGCalEvent(original.googleEventId, updated, token)
          showToast(ok ? '📅 Google Calendar 일정이 수정되었습니다!' : '❌ Google Calendar 일정 수정에 실패했습니다.')
        } else {
          showToast('⚠️ Google Calendar 토큰 만료. 연동 버튼을 다시 눌러주세요.')
        }
      }
    } else {
      const newTrip: Trip = {
        id: Date.now(),
        destination: form.destination,
        purpose: form.purpose,
        companion: form.companion || undefined,
        startDate: form.startDate,
        endDate: form.endDate,
        expenseStatus: form.expenseStatus,
        amount: form.amount ? Number(form.amount) : undefined,
        note: form.note,
      }
      setTrips((prev) => [newTrip, ...prev])

      // Google Calendar 일정 생성 (기존 로직 유지)
      if (gcalConnectedRef.current) {
        const token = await getToken()
        if (token) {
          const eventId = await createGCalEvent(newTrip, token)
          if (eventId) {
            setTrips((prev) => prev.map((t) => t.id === newTrip.id ? { ...t, googleEventId: eventId } : t))
            showToast('📅 Google Calendar에 일정이 추가되었습니다!')
          } else {
            showToast('❌ Google Calendar 일정 생성에 실패했습니다.')
          }
        }
      }
    }
  }

  async function deleteTrip(id: number) {
    const trip = trips.find((t) => t.id === id)
    // Google Calendar 먼저 삭제 (event_id 있는 경우만), 그 다음 로컬 삭제
    if (gcalConnectedRef.current && trip?.googleEventId) {
      const token = await getToken()
      if (token) {
        const ok = await deleteGCalEvent(trip.googleEventId, token)
        if (!ok) showToast('❌ Google Calendar 일정 삭제에 실패했습니다.')
      } else {
        showToast('⚠️ Google Calendar 토큰 만료. 연동 버튼을 다시 눌러주세요.')
      }
    }
    setTrips((prev) => prev.filter((t) => t.id !== id))
    setChecked((prev) => { const n = new Set(prev); n.delete(id); return n })
    setDetailId(null)
  }

  function toggleCheck(id: number) {
    setChecked((prev) => {
      const n = new Set(prev)
      if (n.has(id)) n.delete(id); else n.add(id)
      return n
    })
  }

  async function deleteChecked() {
    const toDelete = trips.filter((t) => checked.has(t.id))
    setTrips((prev) => prev.filter((t) => !checked.has(t.id)))
    setChecked(new Set())

    // Google Calendar 일정 일괄 삭제 (event_id 있는 것만)
    if (gcalConnectedRef.current) {
      const token = await getToken()
      if (token) {
        for (const trip of toDelete) {
          if (trip.googleEventId) await deleteGCalEvent(trip.googleEventId, token)
        }
      }
    }
  }

  const FILTER_TABS_ROW1: { key: ExpenseStatus | '전체'; dotColor: string }[] = [
    { key: '전체', dotColor: '#00A0E9' },
    { key: '미신청', dotColor: '#9ca3af' },
    { key: '진행중', dotColor: '#F5C518' },
    { key: '신청완료', dotColor: '#22c55e' },
  ]

  if (showSplash) return (
    <div className="min-h-screen flex flex-col items-center justify-center font-sans px-6"
      style={{ background: '#00A0E9' }}>
      {/* 도트 패턴 */}
      <div className="fixed inset-0 pointer-events-none"
        style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.12) 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

      {/* 장식 원 */}
      <div className="absolute top-[-60px] left-[-60px] w-48 h-48 rounded-full pointer-events-none"
        style={{ background: 'rgba(255,255,255,0.08)' }} />
      <div className="absolute bottom-[-40px] right-[-40px] w-36 h-36 rounded-full pointer-events-none"
        style={{ background: 'rgba(255,255,255,0.06)' }} />

      <div className="relative w-full max-w-xs text-center">
        {/* 도라에몽 흰 원 */}
        <div className="flex justify-center mb-6">
          <div className="relative flex items-center justify-center w-44 h-44 rounded-full"
            style={{ background: 'white', boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}>
            <div className="absolute w-52 h-52 rounded-full"
              style={{ background: 'rgba(255,255,255,0.15)' }} />
            <DoraemonHappy size={108} />
          </div>
        </div>

        {/* 타이틀 */}
        <h1 className="text-3xl font-extrabold text-white tracking-tight mb-1">출장포켓</h1>
        <p className="text-white/70 font-bold text-base mb-1">TripPocket</p>
        <p className="text-white/50 text-sm mb-10">어디든 문 · 출장 기록부</p>

        {/* 어디든 문 버튼 */}
        <button
          onClick={() => setShowSplash(false)}
          disabled={dbLoading}
          className="w-full font-extrabold text-lg py-4 px-6 rounded-2xl transition-all hover:scale-105 active:scale-95 flex items-center justify-center gap-3 disabled:opacity-70"
          style={{ background: 'white', color: '#00A0E9', boxShadow: '0 6px 0 rgba(0,0,0,0.15)' }}
        >
          {dbLoading ? (
            <>
              <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="#00A0E9" strokeWidth="3" strokeDasharray="32" strokeDashoffset="10" strokeLinecap="round"/>
              </svg>
              데이터 불러오는 중...
            </>
          ) : (
            <>
              <span style={{ fontSize: '22px' }}>🚪</span>
              어디든 문
            </>
          )}
        </button>

        <p className="text-white/40 text-[10px] mt-6">출장 기록을 시작해보세요</p>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen font-sans" style={{ background: 'linear-gradient(160deg, #e0f4ff 0%, #cceeff 40%, #ddf2ff 100%)' }}>
      <div className="fixed inset-0 pointer-events-none"
        style={{ backgroundImage: 'radial-gradient(circle, #00A0E933 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

      {/* Header */}
      <header className="relative sticky top-0 z-10" style={{ background: '#00A0E9', borderBottom: '3px solid #0080C0' }}>
        <div className="max-w-4xl mx-auto px-5 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DoraemonFace size={40} />
            <div>
              <h1 className="text-white font-extrabold text-lg leading-none tracking-tight">출장포켓 TripPocket</h1>
              {!isSharedView && (
                <p className="mt-0.5 flex items-center gap-1">
                  {dbReady
                    ? <><span style={{ display: 'inline-block', width: 5, height: 5, borderRadius: '50%', background: '#86efac' }} />
                      <span className="text-[9px] text-green-200 font-medium">클라우드 저장 중</span></>
                    : <><span style={{ display: 'inline-block', width: 5, height: 5, borderRadius: '50%', background: '#fde68a' }} />
                      <span className="text-[9px] text-yellow-200 font-medium">내 기기 저장 중</span></>
                  }
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {/* Google Calendar 연동 버튼 (항상 노출) */}
            {!isSharedView && GOOGLE_CLIENT_ID && (
              <button
                onClick={handleConnectGCal}
                className="flex items-center gap-1 font-bold text-[10px] px-2 py-1.5 rounded-full transition-all hover:scale-105 active:scale-95"
                style={gcalConnected
                  ? { background: '#22c55e', color: 'white', border: '2px solid #16a34a' }
                  : { background: 'rgba(255,255,255,0.2)', color: 'white', border: '2px solid rgba(255,255,255,0.4)' }}
              >
                <span style={{ whiteSpace: 'nowrap' }}>📅 {gcalConnected ? '연동중' : 'Calendar'}</span>
              </button>
            )}
            {/* 출장 추가 */}
            {!isSharedView && (
              <button
                onClick={openAdd}
                className="flex items-center gap-1 font-bold text-[10px] px-2.5 py-1.5 rounded-full shadow-md transition-all hover:scale-105 active:scale-95"
                style={{ background: '#E60012', color: 'white', boxShadow: '0 2px 0 #a00010', whiteSpace: 'nowrap' }}
              >
                <span className="text-xs leading-none">+</span> 출장 추가
              </button>
            )}
            {/* ⋮ 더보기 — 링크 공유 · CSV만 */}
            {!isSharedView && (
              <div className="relative">
                <button
                  onClick={() => setShowMoreMenu((v) => !v)}
                  className="w-8 h-8 flex items-center justify-center rounded-full font-bold text-base transition-all hover:scale-105 active:scale-95"
                  style={{ background: showMoreMenu ? 'white' : 'rgba(255,255,255,0.2)', color: showMoreMenu ? '#00A0E9' : 'white', border: '2px solid rgba(255,255,255,0.4)' }}
                >
                  ⋮
                </button>
                {showMoreMenu && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowMoreMenu(false)} />
                    <div className="absolute right-0 top-full mt-2 rounded-2xl overflow-hidden shadow-2xl z-50 w-44"
                      style={{ background: 'white', border: '2px solid #bee3f8' }}>
                      <button
                        onClick={() => { handleShare(); setShowMoreMenu(false) }}
                        className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-left transition-colors hover:bg-blue-50"
                        style={{ color: '#1e3a5f', borderBottom: '1px solid #e0f0fa' }}
                      >
                        <span>🔗</span> 링크 공유
                      </button>
                      <button
                        onClick={() => { exportCSV(); setShowMoreMenu(false) }}
                        className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-left transition-colors hover:bg-blue-50"
                        style={{ color: '#1e3a5f' }}
                      >
                        <span>📊</span> CSV 내보내기
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {isSharedView && (
        <div className="relative z-10 flex items-center justify-center gap-2 py-2.5 text-xs font-bold text-white"
          style={{ background: '#0070a0' }}>
          <span>👀 공유된 출장 목록 (읽기 전용)</span>
          <a href={window.location.origin + window.location.pathname}
            className="underline opacity-80 hover:opacity-100">내 목록 열기</a>
        </div>
      )}

      <main className="relative max-w-4xl mx-auto px-5 py-7">

        {/* 월별 예상 출장비 */}
        {monthlyStats.length > 0 && (() => {
          const statKeys = monthlyStats.map(([k]) => k)
          const totalStat = { count: trips.length, total: trips.reduce((s, t) => s + (t.amount ?? 0), 0) }
          const isTotal = selectedStatMonth === 'total'
          const resolvedMonth = statKeys.includes(selectedStatMonth) ? selectedStatMonth : (statKeys[0] ?? 'total')
          const displayKey = isTotal ? 'total' : resolvedMonth
          const displayStat = isTotal ? totalStat : (monthlyStats.find(([k]) => k === displayKey)?.[1] ?? { count: 0, total: 0 })
          const [year, month] = isTotal ? ['', ''] : displayKey.split('-')
          return (
            <div className="mb-5">
              <div className="flex items-center gap-2 mb-2.5">
                <svg width="26" height="26" viewBox="0 0 36 36" fill="none">
                  <rect x="2" y="10" width="32" height="22" rx="6" fill="#00A0E9"/>
                  <rect x="2" y="10" width="32" height="8" rx="4" fill="#0080C0"/>
                  <path d="M10 10 Q10 4 18 4 Q26 4 26 10" stroke="#0080C0" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
                  <rect x="22" y="17" width="10" height="8" rx="4" fill="#F5C518"/>
                  <circle cx="27" cy="21" r="2.5" fill="#E6A800"/>
                  <circle cx="27" cy="21" r="1.2" fill="#1a1a1a"/>
                </svg>
                <p className="text-sm font-bold text-blue-500 tracking-wide">월별 예상 출장비</p>
              </div>

              {/* 월 선택 탭 */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 mb-3" style={{ scrollbarWidth: 'none' }}>
                {/* 총계 탭 */}
                <button
                  onClick={() => setSelectedStatMonth('total')}
                  className="shrink-0 text-[11px] font-bold px-3 py-1.5 rounded-full transition-all"
                  style={displayKey === 'total'
                    ? { background: '#F5C518', color: '#7a5800', boxShadow: '0 2px 0 #E6A800' }
                    : { background: 'white', color: '#3b7aaa', border: '2px solid #FFE566' }
                  }
                >
                  전체합산
                </button>
                {monthlyStats.map(([key]) => {
                  const [y, m] = key.split('-')
                  const isTab = key === displayKey
                  return (
                    <button
                      key={key}
                      onClick={() => setSelectedStatMonth(key)}
                      className="shrink-0 text-[11px] font-bold px-3 py-1.5 rounded-full transition-all"
                      style={isTab
                        ? { background: '#F5C518', color: '#7a5800', boxShadow: '0 2px 0 #E6A800' }
                        : { background: 'white', color: '#3b7aaa', border: '2px solid #FFE566' }
                      }
                    >
                      {y}.{m}
                    </button>
                  )
                })}
              </div>

              {/* 선택된 월 카드 */}
              <button
                onClick={() => setMonthFilter(monthFilter === displayKey ? null : displayKey)}
                className="w-full rounded-2xl px-5 py-4 flex items-center justify-between transition-all hover:scale-[1.01] active:scale-[0.99]"
                style={{
                  background: monthFilter === displayKey ? '#F5C518' : '#FFF9DB',
                  border: `2.5px solid ${monthFilter === displayKey ? '#E6A800' : '#FFE566'}`,
                  boxShadow: monthFilter === displayKey ? '0 4px 0 #E6A80088' : '0 3px 0 #FFE566',
                }}
              >
                <div className="text-left">
                  <p className="text-base font-bold" style={{ color: '#8a6d00' }}>
                    {isTotal ? '전체 합산' : `${year}년 ${month}월`}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: '#b89a00' }}>출장 {displayStat.count}건</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-extrabold font-mono" style={{ color: '#3C1E1E' }}>
                    {displayStat.total > 0 ? formatAmount(displayStat.total) : '—'}
                  </p>
                  {monthFilter === displayKey && (
                    <p className="text-[9px] font-bold mt-0.5" style={{ color: '#a07800' }}>이 달만 보는 중</p>
                  )}
                </div>
              </button>

              {monthFilter && (
                <button onClick={() => setMonthFilter(null)} className="mt-1.5 text-[10px] font-bold text-blue-400 underline">
                  전체 기간 보기
                </button>
              )}
            </div>
          )
        })()}

        {/* 통계 카드 */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-7">
          {([
            { label: '전체 출장', key: '전체', Face: DoraemonFace, accent: '#00A0E9', sub: null },
            { label: '미신청', key: '미신청', Face: DoraemonWorried, accent: '#9ca3af', sub: unpaidTotal > 0 ? formatAmount(unpaidTotal) : null },
            { label: '진행중', key: '진행중', Face: DoraemonThinking, accent: '#F5C518', sub: null },
            { label: '신청완료', key: '신청완료', Face: DoraemonHappy, accent: '#22c55e', sub: null },
          ] as const).map(({ label, key, Face, accent, sub }) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className="text-left rounded-2xl p-4 transition-all hover:scale-105 active:scale-95"
              style={{
                background: filter === key ? accent : 'white',
                border: `3px solid ${filter === key ? accent : '#e2f3fd'}`,
                boxShadow: filter === key ? `0 4px 0 ${accent}88` : '0 3px 0 #c5e8f7',
                color: filter === key ? 'white' : '#1e3a5f',
              }}
            >
              <Face size={40} />
              <p className="text-[11px] mt-1 font-medium opacity-80">{label}</p>
              <p className="text-2xl font-extrabold leading-none mt-0.5">{counts[key]}</p>
              {sub && (
                <div className="mt-1.5 w-full px-1.5 py-1 rounded-xl text-center"
                  style={{ background: filter === key ? 'rgba(255,255,255,0.25)' : '#ffe4ec' }}>
                  <p className="text-[9px] font-extrabold leading-tight truncate"
                    style={{ color: filter === key ? 'white' : '#e05080' }}>
                    총액: {sub}
                  </p>
                </div>
              )}
            </button>
          ))}
        </div>

        {/* 정렬 + 건수 + 페이지 크기 */}
        <div className="flex items-center justify-between mb-3 gap-2">
          <p className="text-xs text-blue-400 font-medium shrink-0">총 {filtered.length}건</p>
          <div className="flex items-center gap-2">
            <select
              value={pageSize}
              onChange={(e) => setPageSize(Number(e.target.value))}
              className="text-[11px] font-bold rounded-full px-2.5 py-1.5 outline-none"
              style={{ background: 'white', border: '2px solid #bee3f8', color: '#3b7aaa' }}
            >
              <option value={5}>5개씩</option>
              <option value={10}>10개씩</option>
            </select>
            <div className="flex items-center gap-1 rounded-full p-0.5" style={{ background: 'white', border: '2px solid #bee3f8' }}>
              <button
                onClick={() => setSortOrder('desc')}
                className="text-[11px] font-bold px-3 py-1 rounded-full transition-all"
                style={sortOrder === 'desc' ? { background: '#00A0E9', color: 'white' } : { color: '#3b7aaa' }}
              >
                최신순
              </button>
              <button
                onClick={() => setSortOrder('asc')}
                className="text-[11px] font-bold px-3 py-1 rounded-full transition-all"
                style={sortOrder === 'asc' ? { background: '#00A0E9', color: 'white' } : { color: '#3b7aaa' }}
              >
                오래된순
              </button>
            </div>
          </div>
        </div>

        {/* 필터 탭 */}
        <div className="flex flex-col gap-1.5 mb-5">
          <div className="grid grid-cols-4 gap-1.5">
            {FILTER_TABS_ROW1.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key)}
                className="flex items-center justify-center gap-1 text-[11px] px-1.5 py-1.5 rounded-full font-bold transition-all hover:scale-105 active:scale-95 whitespace-nowrap"
                style={
                  filter === tab.key
                    ? { background: '#00A0E9', color: 'white', boxShadow: '0 2px 0 #0070a0' }
                    : { background: 'white', color: '#3b7aaa', border: '2px solid #bee3f8' }
                }
              >
                <span style={{ display: 'inline-block', width: 7, height: 7, borderRadius: '50%', background: filter === tab.key ? 'rgba(255,255,255,0.8)' : tab.dotColor, flexShrink: 0 }} />
                {tab.key}
                {tab.key !== '전체' && <span className="opacity-70">({counts[tab.key]})</span>}
              </button>
            ))}
          </div>
        </div>

        {/* 선택 삭제 */}
        {checked.size > 0 && (
          <div className="flex items-center justify-between mb-3 px-1">
            <span className="text-xs text-blue-400 font-bold">{checked.size}건 선택됨</span>
            <button
              onClick={deleteChecked}
              className="text-xs font-extrabold px-4 py-1.5 rounded-full"
              style={{ background: '#E60012', color: 'white', boxShadow: '0 2px 0 #a00010' }}
            >
              🗑️ 선택 삭제
            </button>
          </div>
        )}

        {/* 지출품의 미신청 공지 배너 */}
        {!isSharedView && counts['미신청'] > 0 && (
          <div className="mb-3 flex items-center gap-3 rounded-2xl px-4 py-3 border-2"
            style={{ background: 'white', borderColor: '#fecaca' }}>
            <span className="text-xl shrink-0">🔔</span>
            <p className="text-xs font-bold" style={{ color: '#1e3a5f' }}>
              지출품의 미신청건 <span style={{ color: '#E60012' }}>{counts['미신청']}건</span>이 있어요. 확인해주세요!
            </p>
          </div>
        )}

        {/* 출장 목록 */}
        <div className="space-y-3">
          {filtered.length === 0 && (
            <div className="bg-white rounded-3xl border-2 border-blue-100 py-16 text-center">
              <DoraemonFace size={60} />
              <p className="text-sm text-blue-300 font-medium mt-3">출장 내역이 없습니다</p>
            </div>
          )}

          {pagedTrips.map((trip) => {
            const cfg = STATUS_CONFIG[trip.expenseStatus]
            const days = diffDays(trip.startDate, trip.endDate)
            const isOpen = detailId === trip.id
            const isFuture = trip.startDate > new Date().toISOString().slice(0, 10)

            return (
              <div
                key={trip.id}
                className="rounded-3xl overflow-hidden transition-all"
                style={{
                  background: isFuture ? '#e8f6ff' : 'white',
                  border: isOpen ? '2.5px solid #00A0E9' : isFuture ? '2.5px solid #7dd3fc' : '2.5px solid #e0f0fa',
                  boxShadow: isOpen ? '0 6px 0 #00A0E944' : '0 4px 0 #c5e8f7',
                }}
              >
                <div className="px-3 py-4 flex items-center gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleCheck(trip.id) }}
                    className="shrink-0 w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all"
                    style={{ borderColor: checked.has(trip.id) ? '#E60012' : '#bee3f8', background: checked.has(trip.id) ? '#E60012' : 'white' }}
                  >
                    {checked.has(trip.id) && (
                      <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>

                  <div className="shrink-0 text-center w-11">
                    {isFuture && (
                      <p className="text-[13px] font-extrabold leading-none mb-0.5" style={{ color: '#0ea5e9' }}>예정</p>
                    )}
                    <p className="text-sm font-mono text-blue-500 font-extrabold leading-tight">
                      {trip.startDate.slice(5, 7)}/{trip.startDate.slice(8, 10)}
                    </p>
                    {days > 1 && <p className="text-[10px] text-blue-300 font-bold">{days}일</p>}
                  </div>

                  <div className="shrink-0 flex flex-col gap-1">
                    {[0, 1, 2].map((i) => <div key={i} className="w-1.5 h-1.5 rounded-full bg-blue-200" />)}
                  </div>

                  <button onClick={() => setDetailId(isOpen ? null : trip.id)} className="flex-1 min-w-0 text-left">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ background: STATUS_DOT_COLOR[trip.expenseStatus], boxShadow: `0 0 0 2px ${STATUS_DOT_COLOR[trip.expenseStatus]}33` }} />
                      <span className="text-[10px] font-bold" style={{ color: STATUS_DOT_COLOR[trip.expenseStatus] }}>{cfg.label}</span>
                    </div>
                    <p className="font-extrabold text-[#1e3a5f] text-base leading-tight">📍 {trip.destination}</p>
                    {trip.purpose && <p className="text-xs text-blue-400 mt-0.5 truncate">{trip.purpose}</p>}
                  </button>

                  <button onClick={() => setDetailId(isOpen ? null : trip.id)} className="shrink-0 text-right flex flex-col items-end gap-0.5">
                    {trip.googleEventId && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: '#e8f5e9', color: '#2e7d32' }}>📅</span>
                    )}
                    {trip.companion && (
                      <span className="flex items-center gap-1">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                          <circle cx="12" cy="13" r="8" fill="#F5C518" stroke="#E6A800" strokeWidth="1.2" />
                          <path d="M9 5 Q12 2 15 5" stroke="#E6A800" strokeWidth="1.4" strokeLinecap="round" fill="none" />
                          <circle cx="12" cy="15" r="2.2" fill="#1a1a1a" />
                          <circle cx="8.5" cy="10" r="1.2" fill="white" opacity="0.7" />
                        </svg>
                        <span className="text-xs font-bold text-yellow-500">동행</span>
                      </span>
                    )}
                    {trip.amount
                      ? <span className="font-extrabold font-mono text-[#1e3a5f]" style={{ fontSize: '17px' }}>{formatAmount(trip.amount)}</span>
                      : <span className="text-sm text-blue-200 font-medium">—</span>
                    }
                  </button>

                  <button onClick={() => setDetailId(isOpen ? null : trip.id)} className="shrink-0">
                    <svg className={`w-4 h-4 text-blue-300 transition-transform ${isOpen ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>

                {isOpen && (
                  <div className="border-t-2 border-blue-100 px-5 py-4" style={{ background: '#f0f9ff' }} onClick={(e) => e.stopPropagation()}>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-4">
                      {[
                        { label: '출장지', value: trip.destination },
                        { label: '기간', value: `${formatDate(trip.startDate)}${trip.startDate !== trip.endDate ? ` ~ ${formatDate(trip.endDate)}` : ''} (${days}일)` },
                        { label: '목적', value: trip.purpose },
                        ...(trip.companion ? [{ label: '동행인', value: trip.companion }] : []),
                        { label: '지출품의', value: `${cfg.emoji} ${cfg.label}` },
                        { label: '지출금액', value: trip.amount ? formatAmount(trip.amount) : '—', mono: true },
                        ...(trip.note ? [{ label: '메모', value: trip.note }] : []),
                      ].map(({ label, value, mono }) => (
                        <div key={label}>
                          <p className="text-[9px] text-blue-400 uppercase tracking-widest font-bold mb-1">{label}</p>
                          <p className={`text-sm font-semibold text-[#1e3a5f] ${mono ? 'font-mono' : ''}`}>{value}</p>
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button onClick={() => openEdit(trip)} className="text-xs font-bold px-4 py-1.5 rounded-full transition-all hover:scale-105"
                        style={{ background: '#00A0E9', color: 'white', boxShadow: '0 2px 0 #0070a0' }}>
                        ✏️ 수정
                      </button>
                      <button onClick={() => deleteTrip(trip.id)} className="text-xs font-bold px-4 py-1.5 rounded-full transition-all hover:scale-105"
                        style={{ background: '#fff0f0', color: '#E60012', border: '2px solid #fecaca' }}>
                        🗑️ 삭제
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* 페이지네이션 */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-4">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all disabled:opacity-30"
              style={{ background: 'white', border: '2px solid #bee3f8', color: '#3b7aaa' }}
            >
              ‹
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all"
                style={p === page
                  ? { background: '#00A0E9', color: 'white', boxShadow: '0 2px 0 #0070a0' }
                  : { background: 'white', border: '2px solid #bee3f8', color: '#3b7aaa' }
                }
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all disabled:opacity-30"
              style={{ background: 'white', border: '2px solid #bee3f8', color: '#3b7aaa' }}
            >
              ›
            </button>
          </div>
        )}


        <div className="flex justify-center mt-10 opacity-20">
          <DoraemonFace size={48} />
        </div>

        <footer className="mt-6 mb-8 text-center">
          <p className="text-[10px] text-white/60 font-medium">기획·UX/UI 차상미 · AI개발 ChatGPT·Figma Make · Version 1.0 · 2026</p>
        </footer>
      </main>

      {/* 토스트 알림 */}
      {toast && (
        <div className="fixed top-6 left-1/2 z-[100] -translate-x-1/2 pointer-events-none">
          <div className="px-5 py-3 rounded-2xl font-bold text-sm text-white shadow-xl"
            style={{ background: '#1e3a5f', boxShadow: '0 4px 16px rgba(0,0,0,0.25)' }}>
            {toast}
          </div>
        </div>
      )}

      {/* 공유 모달 */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center"
          style={{ background: 'rgba(0,80,130,0.4)', backdropFilter: 'blur(4px)' }}
          onClick={() => setShowShareModal(false)}>
          <div className="w-full max-w-md rounded-t-3xl overflow-hidden"
            style={{ background: 'white', border: '3px solid #00A0E9', borderBottom: 'none', boxShadow: '0 -6px 24px #00A0E933' }}
            onClick={(e) => e.stopPropagation()}>
            {/* 핸들 */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-blue-200" />
            </div>
            <div className="px-6 pb-2 pt-1 flex items-center gap-2">
              <DoraemonFace size={28} />
              <h3 className="font-extrabold text-[#1e3a5f] text-base">출장 목록 공유하기</h3>
            </div>
            <p className="px-6 text-xs text-blue-400 mb-4">링크를 받은 사람은 내 출장 목록을 볼 수 있어요</p>

            <div className="px-5 pb-8 space-y-2.5">
              {/* 링크 복사 */}
              <button onClick={handleCopyLink}
                className="w-full flex items-center gap-3 px-5 py-3.5 rounded-2xl font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ background: '#00A0E9', color: 'white', boxShadow: '0 3px 0 #0070a0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                </svg>
                링크 복사
              </button>

              {/* 취소 */}
              <button onClick={() => { setShowShareModal(false); setShareUrl('') }}
                className="w-full py-3 rounded-2xl font-bold text-sm text-blue-400"
                style={{ background: '#f0f9ff', border: '2px solid #bee3f8' }}>
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 출장 추가/수정 모달 */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0, 100, 160, 0.35)', backdropFilter: 'blur(4px)' }}
          onClick={() => setShowForm(false)}>
          <div className="w-full max-w-md rounded-3xl overflow-hidden shadow-2xl"
            style={{ border: '3px solid #00A0E9', boxShadow: '0 8px 0 #00A0E955' }}
            onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 flex items-center justify-between" style={{ background: '#00A0E9' }}>
              <div className="flex items-center gap-2">
                <DoraemonFace size={32} />
                <h2 className="text-white font-extrabold text-base">{editId !== null ? '출장 수정' : '출장 추가'}</h2>
              </div>
              <button onClick={() => setShowForm(false)} className="text-white/70 hover:text-white text-xl font-bold leading-none">×</button>
            </div>

            <div className="px-6 py-5 space-y-4 bg-white">
              <DField label="출장지 *">
                <input className="dinput" placeholder="예: 부산, 대전" value={form.destination}
                  onChange={(e) => setForm((f) => ({ ...f, destination: e.target.value }))} />
              </DField>
              <DField label="출장 목적">
                <input className="dinput" placeholder="예: 거래처 미팅" value={form.purpose}
                  onChange={(e) => setForm((f) => ({ ...f, purpose: e.target.value }))} />
              </DField>
              <DField label="동행인">
                <input className="dinput" placeholder="예: 김팀장, 이대리 (없으면 비워두세요)" value={form.companion}
                  onChange={(e) => setForm((f) => ({ ...f, companion: e.target.value }))} />
              </DField>
              <div className="grid grid-cols-2 gap-3">
                <DField label="출발일 *">
                  <input type="date" className="dinput" value={form.startDate}
                    onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))} />
                </DField>
                <DField label="복귀일 *">
                  <input type="date" className="dinput" value={form.endDate}
                    onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))} />
                </DField>
              </div>
              <DField label="처리여부">
                <select className="dinput" value={form.expenseStatus}
                  onChange={(e) => setForm((f) => ({ ...f, expenseStatus: e.target.value as ExpenseStatus }))}>
                  <option value="미신청">📋 미신청</option>
                  <option value="진행중">⏳ 진행중</option>
                  <option value="신청완료">✅ 신청완료</option>
                  <option value="팀장 처리중">👔 팀장 처리중</option>
                  <option value="팀원 처리중">🙋 팀원 처리중</option>
                </select>
              </DField>
              <div className="grid grid-cols-2 gap-3">
                <DField label="지출금액 (원)">
                  <input type="number" className="dinput font-mono" placeholder="0" value={form.amount}
                    onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
                </DField>
                <DField label="메모">
                  <input className="dinput" placeholder="비고사항" value={form.note}
                    onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))} />
                </DField>
              </div>
            </div>

            <div className="px-6 pb-5 flex gap-2 justify-end bg-white border-t-2 border-blue-50 pt-4">
              <button onClick={() => setShowForm(false)} className="text-xs font-bold px-5 py-2 rounded-full"
                style={{ background: '#f0f9ff', color: '#3b7aaa', border: '2px solid #bee3f8' }}>
                취소
              </button>
              <button onClick={saveForm} disabled={!form.destination || !form.startDate || !form.endDate}
                className="text-xs font-extrabold px-5 py-2 rounded-full transition-all hover:scale-105 active:scale-95 disabled:opacity-40"
                style={{ background: '#E60012', color: 'white', boxShadow: '0 3px 0 #a00010' }}>
                저장하기 🔔
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .dinput {
          width: 100%;
          border: 2.5px solid #bee3f8;
          border-radius: 12px;
          padding: 8px 12px;
          font-size: 13px;
          color: #1e3a5f;
          background: #f0f9ff;
          outline: none;
          font-family: inherit;
          font-weight: 500;
          transition: border-color 0.15s;
        }
        .dinput:focus { border-color: #00A0E9; background: white; }
        .dinput::placeholder { color: #93c5fd; }
      `}</style>
    </div>
  )
}

function DField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-[10px] text-blue-400 font-bold uppercase tracking-widest mb-1.5">{label}</label>
      {children}
    </div>
  )
}
