import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// 도라에몽 파비콘
const link = document.createElement('link')
link.rel = 'icon'
link.type = 'image/svg+xml'
link.href = '/favicon.svg'
document.head.appendChild(link)

// OG 메타 태그
const ogImage = `${window.location.origin}/og-image.svg`
const metas: [string, string][] = [
  ['og:title', '출장포켓 TripPocket'],
  ['og:description', '어디든 문 · 출장 기록부 — 내 출장 목록을 확인해보세요!'],
  ['og:image', ogImage],
  ['og:type', 'website'],
  ['og:url', window.location.href],
  ['twitter:card', 'summary_large_image'],
  ['twitter:title', '출장포켓 TripPocket'],
  ['twitter:description', '어디든 문 · 출장 기록부'],
  ['twitter:image', ogImage],
]
metas.forEach(([property, content]) => {
  const meta = document.createElement('meta')
  meta.setAttribute('property', property)
  meta.setAttribute('content', content)
  document.head.appendChild(meta)
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
